import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Home.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13ad0a09"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/kenedy/dev/blog_application/client/src/pages/Home.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import BlogList from "/src/components/BlogList.jsx";
const Home = ({ sortedBlogs }) => {
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(BlogList, { blogs: sortedBlogs }, void 0, false, {
    fileName: "/home/kenedy/dev/blog_application/client/src/pages/Home.jsx",
    lineNumber: 25,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/kenedy/dev/blog_application/client/src/pages/Home.jsx",
    lineNumber: 24,
    columnNumber: 5
  }, this);
};
_c = Home;
export default Home;
var _c;
$RefreshReg$(_c, "Home");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/kenedy/dev/blog_application/client/src/pages/Home.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/kenedy/dev/blog_application/client/src/pages/Home.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS007Ozs7Ozs7Ozs7Ozs7Ozs7QUFMTixPQUFPQSxjQUFjO0FBRXJCLE1BQU1DLE9BQU9BLENBQUMsRUFBRUMsWUFBWSxNQUFNO0FBQ2hDLFNBQ0UsdUJBQUMsU0FDQyxpQ0FBQyxZQUFTLE9BQU9BLGVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ0MsS0FOS0Y7QUFRTixlQUFlQTtBQUFJLElBQUFFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJsb2dMaXN0IiwiSG9tZSIsInNvcnRlZEJsb2dzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSG9tZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEJsb2dMaXN0IGZyb20gJy4uL2NvbXBvbmVudHMvQmxvZ0xpc3QnXG5cbmNvbnN0IEhvbWUgPSAoeyBzb3J0ZWRCbG9ncyB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxCbG9nTGlzdCBibG9ncz17c29ydGVkQmxvZ3N9Lz5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBIb21lXG4iXSwiZmlsZSI6Ii9ob21lL2tlbmVkeS9kZXYvYmxvZ19hcHBsaWNhdGlvbi9jbGllbnQvc3JjL3BhZ2VzL0hvbWUuanN4In0=