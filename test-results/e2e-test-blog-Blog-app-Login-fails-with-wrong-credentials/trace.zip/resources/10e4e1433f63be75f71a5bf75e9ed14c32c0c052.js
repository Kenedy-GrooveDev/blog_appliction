import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13ad0a09"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const LoginForm = ({
  handleLogin,
  username,
  password,
  handleUsernameChange,
  handlePasswordChange
}) => {
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("label", { children: [
      "username:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: username,
          onChange: handleUsernameChange,
          required: true
        },
        void 0,
        false,
        {
          fileName: "/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx",
          lineNumber: 31,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "password:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "password",
          value: password,
          onChange: handlePasswordChange,
          required: true
        },
        void 0,
        false,
        {
          fileName: "/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx",
          lineNumber: 41,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx",
      lineNumber: 39,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx",
    lineNumber: 28,
    columnNumber: 5
  }, this);
};
_c = LoginForm;
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/kenedy/dev/blog_application/client/src/components/LoginForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1E7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYUixNQUFNQSxZQUFZQSxDQUFDO0FBQUEsRUFDakJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUNKLFNBQ0UsdUJBQUMsVUFBSyxVQUFVSixhQUNkO0FBQUEsMkJBQUMsV0FBSztBQUFBO0FBQUEsTUFFSjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsT0FBT0M7QUFBQUEsVUFDUCxVQUFVRTtBQUFBQSxVQUNWLFVBQVE7QUFBQTtBQUFBLFFBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSVU7QUFBQSxTQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUk7QUFBQSxJQUNKLHVCQUFDLFdBQUs7QUFBQTtBQUFBLE1BRUo7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9EO0FBQUFBLFVBQ1AsVUFBVUU7QUFBQUEsVUFDVixVQUFRO0FBQUE7QUFBQSxRQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlVO0FBQUEsU0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLE9BckI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0JBO0FBRUo7QUFBQ0MsS0FoQ0tOO0FBa0NOLGVBQWVBO0FBQVMsSUFBQU07QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTG9naW5Gb3JtIiwiaGFuZGxlTG9naW4iLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwiaGFuZGxlVXNlcm5hbWVDaGFuZ2UiLCJoYW5kbGVQYXNzd29yZENoYW5nZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxvZ2luRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgTG9naW5Gb3JtID0gKHtcbiAgaGFuZGxlTG9naW4sXG4gIHVzZXJuYW1lLFxuICBwYXNzd29yZCxcbiAgaGFuZGxlVXNlcm5hbWVDaGFuZ2UsXG4gIGhhbmRsZVBhc3N3b3JkQ2hhbmdlLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0+XG4gICAgICA8bGFiZWw+XG4gICAgICAgIHVzZXJuYW1lOlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVVc2VybmFtZUNoYW5nZX1cbiAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAvPlxuICAgICAgPC9sYWJlbD5cbiAgICAgIDxicj48L2JyPlxuICAgICAgPGxhYmVsPlxuICAgICAgICBwYXNzd29yZDpcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBhc3N3b3JkQ2hhbmdlfVxuICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgIC8+XG4gICAgICA8L2xhYmVsPlxuICAgICAgPGJyIC8+XG4gICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5sb2dpbjwvYnV0dG9uPlxuICAgIDwvZm9ybT5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBMb2dpbkZvcm1cbiJdLCJmaWxlIjoiL2hvbWUva2VuZWR5L2Rldi9ibG9nX2FwcGxpY2F0aW9uL2NsaWVudC9zcmMvY29tcG9uZW50cy9Mb2dpbkZvcm0uanN4In0=