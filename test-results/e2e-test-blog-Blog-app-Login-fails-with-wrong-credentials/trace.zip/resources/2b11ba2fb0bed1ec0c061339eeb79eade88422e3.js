import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogList.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13ad0a09"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/kenedy/dev/blog_application/client/src/components/BlogList.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=13ad0a09";
const BlogList = ({ blogs }) => {
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("ul", { children: blogs.map(
    (blog) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: `/blogs/${blog.id}`, "data-testid": "blog-link", children: [
      blog.title,
      " by ",
      blog.author
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogList.jsx",
      lineNumber: 27,
      columnNumber: 27
    }, this) }, blog.id, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogList.jsx",
      lineNumber: 27,
      columnNumber: 9
    }, this)
  ) }, void 0, false, {
    fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogList.jsx",
    lineNumber: 25,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogList.jsx",
    lineNumber: 24,
    columnNumber: 5
  }, this);
};
_c = BlogList;
export default BlogList;
var _c;
$RefreshReg$(_c, "BlogList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/kenedy/dev/blog_application/client/src/components/BlogList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/kenedy/dev/blog_application/client/src/components/BlogList.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTzZCOzs7Ozs7Ozs7Ozs7Ozs7O0FBUDdCLFNBQVNBLFlBQVk7QUFFckIsTUFBTUMsV0FBV0EsQ0FBQyxFQUFFQyxNQUFNLE1BQU07QUFDOUIsU0FDRSx1QkFBQyxTQUNDLGlDQUFDLFFBQ0VBLGdCQUFNQztBQUFBQSxJQUFJLENBQUFDLFNBQ1QsdUJBQUMsUUFBa0IsaUNBQUMsUUFBSyxJQUFJLFVBQVVBLEtBQUtDLEVBQUUsSUFBSSxlQUFZLGFBQWFEO0FBQUFBLFdBQUtFO0FBQUFBLE1BQU07QUFBQSxNQUFLRixLQUFLRztBQUFBQSxTQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9GLEtBQTlGSCxLQUFLQyxJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEc7QUFBQSxFQUMvRyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVKO0FBQUNHLEtBVktQO0FBWU4sZUFBZUE7QUFBUSxJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJMaW5rIiwiQmxvZ0xpc3QiLCJibG9ncyIsIm1hcCIsImJsb2ciLCJpZCIsInRpdGxlIiwiYXV0aG9yIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQmxvZ0xpc3QuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuXG5jb25zdCBCbG9nTGlzdCA9ICh7IGJsb2dzIH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPHVsPlxuICAgICAgICB7YmxvZ3MubWFwKGJsb2cgPT4gKFxuICAgICAgICAgIDxsaSBrZXk9e2Jsb2cuaWR9ID48TGluayB0bz17YC9ibG9ncy8ke2Jsb2cuaWR9YH0gZGF0YS10ZXN0aWQ9XCJibG9nLWxpbmtcIj57YmxvZy50aXRsZX0gYnkge2Jsb2cuYXV0aG9yfTwvTGluaz48L2xpPlxuICAgICAgICApKX1cbiAgICAgIDwvdWw+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZ0xpc3RcbiJdLCJmaWxlIjoiL2hvbWUva2VuZWR5L2Rldi9ibG9nX2FwcGxpY2F0aW9uL2NsaWVudC9zcmMvY29tcG9uZW50cy9CbG9nTGlzdC5qc3gifQ==