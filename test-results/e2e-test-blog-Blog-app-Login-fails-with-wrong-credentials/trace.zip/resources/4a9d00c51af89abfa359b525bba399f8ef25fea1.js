import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Navigation.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13ad0a09"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/kenedy/dev/blog_application/client/src/components/Navigation.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=13ad0a09";
const Navigation = ({ user, handleLogOut }) => {
  const padding = { padding: 5 };
  return /* @__PURE__ */ jsxDEV("nav", { children: [
    /* @__PURE__ */ jsxDEV(Link, { style: padding, to: "/", children: "blogs" }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/Navigation.jsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    user ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Link, { style: padding, to: "/create", children: "new blog" }, void 0, false, {
        fileName: "/home/kenedy/dev/blog_application/client/src/components/Navigation.jsx",
        lineNumber: 31,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogOut, children: "logout" }, void 0, false, {
        fileName: "/home/kenedy/dev/blog_application/client/src/components/Navigation.jsx",
        lineNumber: 32,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/Navigation.jsx",
      lineNumber: 30,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Link, { style: padding, to: "/login", children: "login" }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/Navigation.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/kenedy/dev/blog_application/client/src/components/Navigation.jsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
};
_c = Navigation;
export default Navigation;
var _c;
$RefreshReg$(_c, "Navigation");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/kenedy/dev/blog_application/client/src/components/Navigation.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/kenedy/dev/blog_application/client/src/components/Navigation.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT00sU0FHRSxVQUhGOzs7Ozs7Ozs7Ozs7Ozs7O0FBUE4sU0FBU0EsWUFBWTtBQUVyQixNQUFNQyxhQUFhQSxDQUFDLEVBQUVDLE1BQU1DLGFBQWEsTUFBTTtBQUM3QyxRQUFNQyxVQUFVLEVBQUVBLFNBQVMsRUFBRTtBQUU3QixTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFLLE9BQU9BLFNBQVMsSUFBRyxLQUFJLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDO0FBQUEsSUFFakNGLE9BQ0MsbUNBQ0U7QUFBQSw2QkFBQyxRQUFLLE9BQU9FLFNBQVMsSUFBRyxXQUFVLHdCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJDO0FBQUEsTUFDM0MsdUJBQUMsWUFBTyxTQUFTRCxjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsU0FGdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBLElBRUEsdUJBQUMsUUFBSyxPQUFPQyxTQUFTLElBQUcsVUFBUyxxQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QztBQUFBLE9BVDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUVKO0FBQUNDLEtBakJLSjtBQW1CTixlQUFlQTtBQUFVLElBQUFJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkxpbmsiLCJOYXZpZ2F0aW9uIiwidXNlciIsImhhbmRsZUxvZ091dCIsInBhZGRpbmciLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOYXZpZ2F0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcblxuY29uc3QgTmF2aWdhdGlvbiA9ICh7IHVzZXIsIGhhbmRsZUxvZ091dCB9KSA9PiB7XG4gIGNvbnN0IHBhZGRpbmcgPSB7IHBhZGRpbmc6IDUgfVxuXG4gIHJldHVybiAoXG4gICAgPG5hdj5cbiAgICAgIDxMaW5rIHN0eWxlPXtwYWRkaW5nfSB0bz1cIi9cIj5ibG9nczwvTGluaz5cblxuICAgICAge3VzZXIgPyAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPExpbmsgc3R5bGU9e3BhZGRpbmd9IHRvPVwiL2NyZWF0ZVwiPm5ldyBibG9nPC9MaW5rPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nT3V0fT5sb2dvdXQ8L2J1dHRvbj5cbiAgICAgICAgPC8+XG4gICAgICApIDogKFxuICAgICAgICA8TGluayBzdHlsZT17cGFkZGluZ30gdG89XCIvbG9naW5cIj5sb2dpbjwvTGluaz5cbiAgICAgICl9XG4gICAgPC9uYXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTmF2aWdhdGlvblxuIl0sImZpbGUiOiIvaG9tZS9rZW5lZHkvZGV2L2Jsb2dfYXBwbGljYXRpb24vY2xpZW50L3NyYy9jb21wb25lbnRzL05hdmlnYXRpb24uanN4In0=