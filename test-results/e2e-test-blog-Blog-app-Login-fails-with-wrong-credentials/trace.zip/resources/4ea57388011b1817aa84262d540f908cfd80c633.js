import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13ad0a09"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=13ad0a09"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({ createBlog }) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    createBlog({ title, author, url });
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "create new" }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "title:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: title,
          name: "title",
          placeholder: "write title here",
          onChange: ({ target }) => setTitle(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
          lineNumber: 40,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
      lineNumber: 47,
      columnNumber: 15
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "author:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: author,
          name: "author",
          placeholder: "write author here",
          onChange: ({ target }) => setAuthor(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
          lineNumber: 50,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
      lineNumber: 57,
      columnNumber: 15
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "url:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: url,
          name: "url",
          placeholder: "write url here",
          onChange: ({ target }) => setUrl(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
          lineNumber: 60,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
      lineNumber: 58,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
      lineNumber: 67,
      columnNumber: 15
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
      lineNumber: 68,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
};
_s(BlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/kenedy/dev/blog_application/client/src/components/BlogForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCTixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQyxFQUFFQyxXQUFXLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUwsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ00sUUFBUUMsU0FBUyxJQUFJUCxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDUSxLQUFLQyxNQUFNLElBQUlULFNBQVMsRUFBRTtBQUVqQyxRQUFNVSxlQUFlQSxDQUFDQyxVQUFVO0FBQzlCQSxVQUFNQyxlQUFlO0FBQ3JCVixlQUFXLEVBQUVFLE9BQU9FLFFBQVFFLElBQUksQ0FBQztBQUNqQ0gsYUFBUyxFQUFFO0FBQ1hFLGNBQVUsRUFBRTtBQUNaRSxXQUFPLEVBQUU7QUFBQSxFQUNYO0FBRUEsU0FDRSx1QkFBQyxVQUFLLFVBQVVDLGNBQ2Q7QUFBQSwyQkFBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYztBQUFBLElBQ2QsdUJBQUMsV0FBSztBQUFBO0FBQUEsTUFFSjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsT0FBT047QUFBQUEsVUFDUCxNQUFLO0FBQUEsVUFDTCxhQUFZO0FBQUEsVUFDWixVQUFVLENBQUMsRUFBRVMsT0FBTyxNQUFNUixTQUFTUSxPQUFPQyxLQUFLO0FBQUE7QUFBQSxRQUxqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLbUQ7QUFBQSxTQVByRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUFRLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDWCx1QkFBQyxXQUFLO0FBQUE7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPUjtBQUFBQSxVQUNQLE1BQUs7QUFBQSxVQUNMLGFBQVk7QUFBQSxVQUNaLFVBQVUsQ0FBQyxFQUFFTyxPQUFPLE1BQU1OLFVBQVVNLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFFBTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtvRDtBQUFBLFNBUHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQVEsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNYLHVCQUFDLFdBQUs7QUFBQTtBQUFBLE1BRUo7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9OO0FBQUFBLFVBQ1AsTUFBSztBQUFBLFVBQ0wsYUFBWTtBQUFBLFVBQ1osVUFBVSxDQUFDLEVBQUVLLE9BQU8sTUFBTUosT0FBT0ksT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFML0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS2lEO0FBQUEsU0FQbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFBUSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ1gsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxPQWhDOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlDQTtBQUVKO0FBQUNYLEdBakRLRixVQUFRO0FBQUEsS0FBUkE7QUFtRE4sZUFBZUE7QUFBUSxJQUFBYztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkJsb2dGb3JtIiwiY3JlYXRlQmxvZyIsIl9zIiwidGl0bGUiLCJzZXRUaXRsZSIsImF1dGhvciIsInNldEF1dGhvciIsInVybCIsInNldFVybCIsImhhbmRsZVN1Ym1pdCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJsb2dGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBCbG9nRm9ybSA9ICh7IGNyZWF0ZUJsb2cgfSkgPT4ge1xuICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbYXV0aG9yLCBzZXRBdXRob3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFt1cmwsIHNldFVybF0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgY3JlYXRlQmxvZyh7IHRpdGxlLCBhdXRob3IsIHVybCB9KVxuICAgIHNldFRpdGxlKCcnKVxuICAgIHNldEF1dGhvcignJylcbiAgICBzZXRVcmwoJycpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgPGgyPmNyZWF0ZSBuZXc8L2gyPlxuICAgICAgPGxhYmVsPlxuICAgICAgICB0aXRsZTpcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIHZhbHVlPXt0aXRsZX1cbiAgICAgICAgICBuYW1lPVwidGl0bGVcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwid3JpdGUgdGl0bGUgaGVyZVwiXG4gICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRUaXRsZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAvPlxuICAgICAgPC9sYWJlbD48YnIgLz5cbiAgICAgIDxsYWJlbD5cbiAgICAgICAgYXV0aG9yOlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgdmFsdWU9e2F1dGhvcn1cbiAgICAgICAgICBuYW1lPVwiYXV0aG9yXCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIndyaXRlIGF1dGhvciBoZXJlXCJcbiAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldEF1dGhvcih0YXJnZXQudmFsdWUpfVxuICAgICAgICAvPlxuICAgICAgPC9sYWJlbD48YnIgLz5cbiAgICAgIDxsYWJlbD5cbiAgICAgICAgdXJsOlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgdmFsdWU9e3VybH1cbiAgICAgICAgICBuYW1lPVwidXJsXCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIndyaXRlIHVybCBoZXJlXCJcbiAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVybCh0YXJnZXQudmFsdWUpfVxuICAgICAgICAvPlxuICAgICAgPC9sYWJlbD48YnIgLz5cbiAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmNyZWF0ZTwvYnV0dG9uPlxuICAgIDwvZm9ybT5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nRm9ybVxuIl0sImZpbGUiOiIvaG9tZS9rZW5lZHkvZGV2L2Jsb2dfYXBwbGljYXRpb24vY2xpZW50L3NyYy9jb21wb25lbnRzL0Jsb2dGb3JtLmpzeCJ9