import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13ad0a09"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/kenedy/dev/blog_application/client/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=13ad0a09"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Routes, Route, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=13ad0a09";
import blogService from "/src/services/blogs.js";
import loginServices from "/src/services/login.js";
import Notification from "/src/components/Notification.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
import Navigation from "/src/components/Navigation.jsx";
import Login from "/src/pages/Login.jsx";
import Home from "/src/pages/Home.jsx";
import Blog from "/src/pages/Blog.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [notifyMessage, setNotifyMessage] = useState(null);
  const localStorageUser = "loggedBlogUser";
  const navigate = useNavigate();
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem(localStorageUser);
    if (loggedUserJSON) {
      const loggedUser = JSON.parse(loggedUserJSON);
      setUser(loggedUser);
      blogService.setToken(loggedUser.token);
    }
  }, []);
  const handleCreate = async (blog) => {
    try {
      const createdBlog = await blogService.create(blog);
      setBlogs((prevBlogs) => [...prevBlogs, createdBlog]);
      setNotifyMessage({
        message: `a new blog ${createdBlog.title} by ${createdBlog.author} added`,
        variant: "green"
      });
    } catch (error) {
      setNotifyMessage({
        message: error.response?.data?.error || "Failed to create blog",
        variant: "red"
      });
    }
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const loggedUser = await loginServices.login({ username, password });
      window.localStorage.setItem(
        localStorageUser,
        JSON.stringify(loggedUser)
      );
      blogService.setToken(loggedUser.token);
      setUser(loggedUser);
      setUsername("");
      setPassword("");
      setNotifyMessage({
        message: `Welcome back, ${loggedUser.name}!`,
        variant: "green"
      });
      navigate("/");
    } catch (error) {
      console.log(error);
      setNotifyMessage({
        message: "wrong username or password",
        variant: "red"
      });
    }
  };
  const handleLogOut = () => {
    window.localStorage.removeItem(localStorageUser);
    setNotifyMessage({
      message: "Logged out Successfully",
      variant: "green"
    });
    setUser(null);
    navigate("/login");
  };
  const handleLike = async (blog) => {
    try {
      const updatedBlog = {
        ...blog,
        likes: blog.likes + 1,
        user: typeof blog.user === "object" ? blog.user.id : blog.user
      };
      const returnedBlog = await blogService.update(updatedBlog, blog.id);
      setBlogs(
        (prevBlogs) => prevBlogs.map(
          (currentBlog) => currentBlog.id === returnedBlog.id ? returnedBlog : currentBlog
        )
      );
    } catch (error) {
      console.log(error);
      setNotifyMessage({
        message: "Failed to like blog",
        variant: "red"
      });
    }
  };
  const removeBlog = (id) => {
    setBlogs((prevBlogs) => prevBlogs.filter((blog) => blog.id !== id));
    setNotifyMessage({
      message: "Blog removed successfully",
      variant: "green"
    });
  };
  const sortedBlogs = [...blogs].sort((a, b) => b.likes - a.likes);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navigation, { user, handleLogOut }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
      lineNumber: 141,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
      lineNumber: 143,
      columnNumber: 7
    }, this),
    notifyMessage && /* @__PURE__ */ jsxDEV(
      Notification,
      {
        message: notifyMessage.message,
        variant: notifyMessage.variant
      },
      void 0,
      false,
      {
        fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
        lineNumber: 146,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/login", element: /* @__PURE__ */ jsxDEV(
        Login,
        {
          handleLogin,
          setPassword,
          setUsername,
          username,
          password
        },
        void 0,
        false,
        {
          fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
          lineNumber: 155,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
        lineNumber: 154,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        Home,
        {
          removeBlog,
          sortedBlogs,
          handleLike,
          user
        },
        void 0,
        false,
        {
          fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
          lineNumber: 167,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
        lineNumber: 166,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
        lineNumber: 164,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          path: "/blogs/:id",
          element: /* @__PURE__ */ jsxDEV(
            Blog,
            {
              removeBlog,
              handleLike,
              loggedInUser: user,
              blogs: sortedBlogs
            },
            void 0,
            false,
            {
              fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
              lineNumber: 179,
              columnNumber: 11
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
          lineNumber: 176,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Route, { path: "create", element: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: handleCreate }, void 0, false, {
        fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
        lineNumber: 188,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
        lineNumber: 187,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
      lineNumber: 153,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/kenedy/dev/blog_application/client/src/App.jsx",
    lineNumber: 139,
    columnNumber: 5
  }, this);
};
_s(App, "jSMJ4ciWlQNT3lpRByNMU1uvOzE=", false, function() {
  return [useNavigate];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/kenedy/dev/blog_application/client/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/kenedy/dev/blog_application/client/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUhNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpITixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsUUFBUUMsT0FBT0MsbUJBQW1CO0FBQzNDLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNoQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSWhCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNpQixVQUFVQyxXQUFXLElBQUlsQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDbUIsVUFBVUMsV0FBVyxJQUFJcEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3FCLE1BQU1DLE9BQU8sSUFBSXRCLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUN1QixlQUFlQyxnQkFBZ0IsSUFBSXhCLFNBQVMsSUFBSTtBQUV2RCxRQUFNeUIsbUJBQW1CO0FBQ3pCLFFBQU1DLFdBQVd0QixZQUFZO0FBRTdCSCxZQUFVLE1BQU07QUFDZEksZ0JBQVlzQixPQUFPLEVBQUVDLEtBQUssQ0FBQWIsV0FBU0MsU0FBU0QsTUFBSyxDQUFDO0FBQUEsRUFDcEQsR0FBRyxFQUFFO0FBRUxkLFlBQVUsTUFBTTtBQUNkLFVBQU00QixpQkFBaUJDLE9BQU9DLGFBQWFDLFFBQVFQLGdCQUFnQjtBQUNuRSxRQUFJSSxnQkFBZ0I7QUFDbEIsWUFBTUksYUFBYUMsS0FBS0MsTUFBTU4sY0FBYztBQUM1Q1AsY0FBUVcsVUFBVTtBQUNsQjVCLGtCQUFZK0IsU0FBU0gsV0FBV0ksS0FBSztBQUFBLElBQ3ZDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNQyxlQUFlLE9BQU9DLFNBQVM7QUFDbkMsUUFBSTtBQUNGLFlBQU1DLGNBQWMsTUFBTW5DLFlBQVlvQyxPQUFPRixJQUFJO0FBQ2pEdkIsZUFBUyxDQUFBMEIsY0FBYSxDQUFDLEdBQUdBLFdBQVdGLFdBQVcsQ0FBQztBQUNqRGhCLHVCQUFpQjtBQUFBLFFBQ2ZtQixTQUFTLGNBQWNILFlBQVlJLEtBQUssT0FBT0osWUFBWUssTUFBTTtBQUFBLFFBQ2pFQyxTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQUEsSUFDSCxTQUFTQyxPQUFPO0FBQ2R2Qix1QkFBaUI7QUFBQSxRQUNmbUIsU0FBU0ksTUFBTUMsVUFBVUMsTUFBTUYsU0FBUztBQUFBLFFBQ3hDRCxTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNSSxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFDckIsUUFBSTtBQUNGLFlBQU1uQixhQUFhLE1BQU0zQixjQUFjK0MsTUFBTSxFQUFFcEMsVUFBVUUsU0FBUyxDQUFDO0FBQ25FVyxhQUFPQyxhQUFhdUI7QUFBQUEsUUFDbEI3QjtBQUFBQSxRQUNBUyxLQUFLcUIsVUFBVXRCLFVBQVU7QUFBQSxNQUMzQjtBQUNBNUIsa0JBQVkrQixTQUFTSCxXQUFXSSxLQUFLO0FBQ3JDZixjQUFRVyxVQUFVO0FBQ2xCZixrQkFBWSxFQUFFO0FBQ2RFLGtCQUFZLEVBQUU7QUFDZEksdUJBQWlCO0FBQUEsUUFDZm1CLFNBQVMsaUJBQWlCVixXQUFXdUIsSUFBSTtBQUFBLFFBQ3pDVixTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQ0RwQixlQUFTLEdBQUc7QUFBQSxJQUNkLFNBQVNxQixPQUFPO0FBQ2RVLGNBQVFDLElBQUlYLEtBQUs7QUFDakJ2Qix1QkFBaUI7QUFBQSxRQUNmbUIsU0FBUztBQUFBLFFBQ1RHLFNBQVM7QUFBQSxNQUNYLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1hLGVBQWVBLE1BQU07QUFDekI3QixXQUFPQyxhQUFhNkIsV0FBV25DLGdCQUFnQjtBQUMvQ0QscUJBQWlCO0FBQUEsTUFDZm1CLFNBQVM7QUFBQSxNQUNURyxTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0R4QixZQUFRLElBQUk7QUFDWkksYUFBUyxRQUFRO0FBQUEsRUFDbkI7QUFFQSxRQUFNbUMsYUFBYSxPQUFPdEIsU0FBUztBQUNqQyxRQUFJO0FBQ0YsWUFBTXVCLGNBQWM7QUFBQSxRQUNsQixHQUFHdkI7QUFBQUEsUUFDSHdCLE9BQU94QixLQUFLd0IsUUFBUTtBQUFBLFFBQ3BCMUMsTUFBTSxPQUFPa0IsS0FBS2xCLFNBQVMsV0FBV2tCLEtBQUtsQixLQUFLMkMsS0FBS3pCLEtBQUtsQjtBQUFBQSxNQUM1RDtBQUNBLFlBQU00QyxlQUFlLE1BQU01RCxZQUFZNkQsT0FBT0osYUFBYXZCLEtBQUt5QixFQUFFO0FBQ2xFaEQ7QUFBQUEsUUFBUyxDQUFBMEIsY0FDUEEsVUFBVXlCO0FBQUFBLFVBQUksQ0FBQUMsZ0JBQ1pBLFlBQVlKLE9BQU9DLGFBQWFELEtBQUtDLGVBQWVHO0FBQUFBLFFBQ3REO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBU3JCLE9BQU87QUFDZFUsY0FBUUMsSUFBSVgsS0FBSztBQUNqQnZCLHVCQUFpQjtBQUFBLFFBQ2ZtQixTQUFTO0FBQUEsUUFDVEcsU0FBUztBQUFBLE1BQ1gsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTXVCLGFBQWFBLENBQUNMLE9BQU87QUFDekJoRCxhQUFTLENBQUEwQixjQUFhQSxVQUFVNEIsT0FBTyxDQUFBL0IsU0FBUUEsS0FBS3lCLE9BQU9BLEVBQUUsQ0FBQztBQUM5RHhDLHFCQUFpQjtBQUFBLE1BQ2ZtQixTQUFTO0FBQUEsTUFDVEcsU0FBUztBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNeUIsY0FBYyxDQUFDLEdBQUd4RCxLQUFLLEVBQUV5RCxLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVYLFFBQVFVLEVBQUVWLEtBQUs7QUFFL0QsU0FDRSx1QkFBQyxTQUVDO0FBQUEsMkJBQUMsY0FBVyxNQUFZLGdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1EO0FBQUEsSUFFbkQsdUJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUVSeEMsaUJBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVNBLGNBQWNvQjtBQUFBQSxRQUN2QixTQUFTcEIsY0FBY3VCO0FBQUFBO0FBQUFBLE1BRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVpQztBQUFBLElBS25DLHVCQUFDLFVBQ0M7QUFBQSw2QkFBQyxTQUFNLE1BQUssVUFBUyxTQUNuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUE7QUFBQSxRQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtxQixLQU52QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUM7QUFBQSxNQUVELHVCQUFDLFNBQU0sTUFBSyxLQUFJLFNBRVosdUJBQUMsU0FDQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWEsS0FMZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0EsS0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0M7QUFBQSxNQUNEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0E7QUFBQSxjQUNBLGNBQWN6QjtBQUFBQSxjQUNkLE9BQU9rRDtBQUFBQTtBQUFBQSxZQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlxQjtBQUFBO0FBQUEsUUFQekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU0c7QUFBQSxNQUVILHVCQUFDLFNBQU0sTUFBSyxVQUFTLFNBQ25CLHVCQUFDLFlBQVMsWUFBWWpDLGdCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQztBQUFBLFNBcENIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQ0E7QUFBQSxPQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0RBO0FBRUo7QUFBQ3hCLEdBbEtLRCxLQUFHO0FBQUEsVUFRVVQsV0FBVztBQUFBO0FBQUEsS0FSeEJTO0FBb0tOLGVBQWVBO0FBQUcsSUFBQThEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiUm91dGVzIiwiUm91dGUiLCJ1c2VOYXZpZ2F0ZSIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlcyIsIk5vdGlmaWNhdGlvbiIsIkJsb2dGb3JtIiwiTmF2aWdhdGlvbiIsIkxvZ2luIiwiSG9tZSIsIkJsb2ciLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwibm90aWZ5TWVzc2FnZSIsInNldE5vdGlmeU1lc3NhZ2UiLCJsb2NhbFN0b3JhZ2VVc2VyIiwibmF2aWdhdGUiLCJnZXRBbGwiLCJ0aGVuIiwibG9nZ2VkVXNlckpTT04iLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwibG9nZ2VkVXNlciIsIkpTT04iLCJwYXJzZSIsInNldFRva2VuIiwidG9rZW4iLCJoYW5kbGVDcmVhdGUiLCJibG9nIiwiY3JlYXRlZEJsb2ciLCJjcmVhdGUiLCJwcmV2QmxvZ3MiLCJtZXNzYWdlIiwidGl0bGUiLCJhdXRob3IiLCJ2YXJpYW50IiwiZXJyb3IiLCJyZXNwb25zZSIsImRhdGEiLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJuYW1lIiwiY29uc29sZSIsImxvZyIsImhhbmRsZUxvZ091dCIsInJlbW92ZUl0ZW0iLCJoYW5kbGVMaWtlIiwidXBkYXRlZEJsb2ciLCJsaWtlcyIsImlkIiwicmV0dXJuZWRCbG9nIiwidXBkYXRlIiwibWFwIiwiY3VycmVudEJsb2ciLCJyZW1vdmVCbG9nIiwiZmlsdGVyIiwic29ydGVkQmxvZ3MiLCJzb3J0IiwiYSIsImIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IFJvdXRlcywgUm91dGUsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZXMgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcbmltcG9ydCBCbG9nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvQmxvZ0Zvcm0nXG5pbXBvcnQgTmF2aWdhdGlvbiBmcm9tICcuL2NvbXBvbmVudHMvTmF2aWdhdGlvbidcbmltcG9ydCBMb2dpbiBmcm9tICcuL3BhZ2VzL0xvZ2luJ1xuaW1wb3J0IEhvbWUgZnJvbSAnLi9wYWdlcy9Ib21lJ1xuaW1wb3J0IEJsb2cgZnJvbSAnLi9wYWdlcy9CbG9nJ1xuXG5jb25zdCBBcHAgPSAoKSA9PiB7XG4gIGNvbnN0IFtibG9ncywgc2V0QmxvZ3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtub3RpZnlNZXNzYWdlLCBzZXROb3RpZnlNZXNzYWdlXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgY29uc3QgbG9jYWxTdG9yYWdlVXNlciA9ICdsb2dnZWRCbG9nVXNlcidcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpIC8vIEhvb2sgdG8gcmVkaXJlY3QgdXNlcnMgYWZ0ZXIgbG9nZ2luZyBpblxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYmxvZ1NlcnZpY2UuZ2V0QWxsKCkudGhlbihibG9ncyA9PiBzZXRCbG9ncyhibG9ncykpXG4gIH0sIFtdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgbG9nZ2VkVXNlckpTT04gPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0obG9jYWxTdG9yYWdlVXNlcilcbiAgICBpZiAobG9nZ2VkVXNlckpTT04pIHtcbiAgICAgIGNvbnN0IGxvZ2dlZFVzZXIgPSBKU09OLnBhcnNlKGxvZ2dlZFVzZXJKU09OKVxuICAgICAgc2V0VXNlcihsb2dnZWRVc2VyKVxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4obG9nZ2VkVXNlci50b2tlbilcbiAgICB9XG4gIH0sIFtdKVxuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZSA9IGFzeW5jIChibG9nKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNyZWF0ZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UuY3JlYXRlKGJsb2cpXG4gICAgICBzZXRCbG9ncyhwcmV2QmxvZ3MgPT4gWy4uLnByZXZCbG9ncywgY3JlYXRlZEJsb2ddKVxuICAgICAgc2V0Tm90aWZ5TWVzc2FnZSh7XG4gICAgICAgIG1lc3NhZ2U6IGBhIG5ldyBibG9nICR7Y3JlYXRlZEJsb2cudGl0bGV9IGJ5ICR7Y3JlYXRlZEJsb2cuYXV0aG9yfSBhZGRlZGAsXG4gICAgICAgIHZhcmlhbnQ6ICdncmVlbidcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldE5vdGlmeU1lc3NhZ2Uoe1xuICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8uZXJyb3IgfHwgJ0ZhaWxlZCB0byBjcmVhdGUgYmxvZycsXG4gICAgICAgIHZhcmlhbnQ6ICdyZWQnXG4gICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBsb2dnZWRVc2VyID0gYXdhaXQgbG9naW5TZXJ2aWNlcy5sb2dpbih7IHVzZXJuYW1lLCBwYXNzd29yZCB9KVxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFxuICAgICAgICBsb2NhbFN0b3JhZ2VVc2VyLFxuICAgICAgICBKU09OLnN0cmluZ2lmeShsb2dnZWRVc2VyKVxuICAgICAgKVxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4obG9nZ2VkVXNlci50b2tlbilcbiAgICAgIHNldFVzZXIobG9nZ2VkVXNlcilcbiAgICAgIHNldFVzZXJuYW1lKCcnKVxuICAgICAgc2V0UGFzc3dvcmQoJycpXG4gICAgICBzZXROb3RpZnlNZXNzYWdlKHtcbiAgICAgICAgbWVzc2FnZTogYFdlbGNvbWUgYmFjaywgJHtsb2dnZWRVc2VyLm5hbWV9IWAsXG4gICAgICAgIHZhcmlhbnQ6ICdncmVlbidcbiAgICAgIH0pXG4gICAgICBuYXZpZ2F0ZSgnLycpIC8vIFNtb290aGx5IGJvdW5jZSBiYWNrIHRvIEhvbWUgcGFnZSB2aWV3IGFmdGVyIGFjY2VzcyBhdXRob3JpemF0aW9uXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUubG9nKGVycm9yKVxuICAgICAgc2V0Tm90aWZ5TWVzc2FnZSh7XG4gICAgICAgIG1lc3NhZ2U6ICd3cm9uZyB1c2VybmFtZSBvciBwYXNzd29yZCcsXG4gICAgICAgIHZhcmlhbnQ6ICdyZWQnXG4gICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ091dCA9ICgpID0+IHtcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0obG9jYWxTdG9yYWdlVXNlcilcbiAgICBzZXROb3RpZnlNZXNzYWdlKHtcbiAgICAgIG1lc3NhZ2U6ICdMb2dnZWQgb3V0IFN1Y2Nlc3NmdWxseScsXG4gICAgICB2YXJpYW50OiAnZ3JlZW4nXG4gICAgfSlcbiAgICBzZXRVc2VyKG51bGwpXG4gICAgbmF2aWdhdGUoJy9sb2dpbicpIC8vIFJlZGlyZWN0IHRvIGxvZ2luIHBhZ2Ugb24gbG9nb3V0XG4gIH1cblxuICBjb25zdCBoYW5kbGVMaWtlID0gYXN5bmMgKGJsb2cpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXBkYXRlZEJsb2cgPSB7XG4gICAgICAgIC4uLmJsb2csXG4gICAgICAgIGxpa2VzOiBibG9nLmxpa2VzICsgMSxcbiAgICAgICAgdXNlcjogdHlwZW9mIGJsb2cudXNlciA9PT0gJ29iamVjdCcgPyBibG9nLnVzZXIuaWQgOiBibG9nLnVzZXJcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJldHVybmVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZSh1cGRhdGVkQmxvZywgYmxvZy5pZClcbiAgICAgIHNldEJsb2dzKHByZXZCbG9ncyA9PlxuICAgICAgICBwcmV2QmxvZ3MubWFwKGN1cnJlbnRCbG9nID0+XG4gICAgICAgICAgY3VycmVudEJsb2cuaWQgPT09IHJldHVybmVkQmxvZy5pZCA/IHJldHVybmVkQmxvZyA6IGN1cnJlbnRCbG9nXG4gICAgICAgIClcbiAgICAgIClcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5sb2coZXJyb3IpXG4gICAgICBzZXROb3RpZnlNZXNzYWdlKHtcbiAgICAgICAgbWVzc2FnZTogJ0ZhaWxlZCB0byBsaWtlIGJsb2cnLFxuICAgICAgICB2YXJpYW50OiAncmVkJ1xuICAgICAgfSlcbiAgICB9XG4gIH1cblxuICBjb25zdCByZW1vdmVCbG9nID0gKGlkKSA9PiB7XG4gICAgc2V0QmxvZ3MocHJldkJsb2dzID0+IHByZXZCbG9ncy5maWx0ZXIoYmxvZyA9PiBibG9nLmlkICE9PSBpZCkpXG4gICAgc2V0Tm90aWZ5TWVzc2FnZSh7XG4gICAgICBtZXNzYWdlOiAnQmxvZyByZW1vdmVkIHN1Y2Nlc3NmdWxseScsXG4gICAgICB2YXJpYW50OiAnZ3JlZW4nXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IHNvcnRlZEJsb2dzID0gWy4uLmJsb2dzXS5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcylcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICB7LyogTmF2aWdhdGlvbiBiYXIgaXMgYWx3YXlzIHZpc2libGUgb24gdG9wICovfVxuICAgICAgPE5hdmlnYXRpb24gdXNlcj17dXNlcn0gaGFuZGxlTG9nT3V0PXtoYW5kbGVMb2dPdXR9IC8+XG5cbiAgICAgIDxoMj5ibG9nczwvaDI+XG5cbiAgICAgIHtub3RpZnlNZXNzYWdlICYmIChcbiAgICAgICAgPE5vdGlmaWNhdGlvblxuICAgICAgICAgIG1lc3NhZ2U9e25vdGlmeU1lc3NhZ2UubWVzc2FnZX1cbiAgICAgICAgICB2YXJpYW50PXtub3RpZnlNZXNzYWdlLnZhcmlhbnR9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7LyogUm91dGUgU3dpdGNoYm9hcmQgKi99XG4gICAgICA8Um91dGVzPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9e1xuICAgICAgICAgIDxMb2dpblxuICAgICAgICAgICAgaGFuZGxlTG9naW49e2hhbmRsZUxvZ2lufVxuICAgICAgICAgICAgc2V0UGFzc3dvcmQ9e3NldFBhc3N3b3JkfVxuICAgICAgICAgICAgc2V0VXNlcm5hbWU9e3NldFVzZXJuYW1lfVxuICAgICAgICAgICAgdXNlcm5hbWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgcGFzc3dvcmQ9e3Bhc3N3b3JkfVxuICAgICAgICAgIC8+XG4gICAgICAgIH0gLz5cblxuICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXtcbiAgICAgICAgICAoXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8SG9tZVxuICAgICAgICAgICAgICAgIHJlbW92ZUJsb2c9e3JlbW92ZUJsb2d9XG4gICAgICAgICAgICAgICAgc29ydGVkQmxvZ3M9e3NvcnRlZEJsb2dzfVxuICAgICAgICAgICAgICAgIGhhbmRsZUxpa2U9e2hhbmRsZUxpa2V9XG4gICAgICAgICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIClcbiAgICAgICAgfSAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2Jsb2dzLzppZFwiXG4gICAgICAgICAgZWxlbWVudD17XG4gICAgICAgICAgICA8QmxvZ1xuICAgICAgICAgICAgICByZW1vdmVCbG9nPXtyZW1vdmVCbG9nfVxuICAgICAgICAgICAgICBoYW5kbGVMaWtlPXtoYW5kbGVMaWtlfVxuICAgICAgICAgICAgICBsb2dnZWRJblVzZXI9e3VzZXJ9XG4gICAgICAgICAgICAgIGJsb2dzPXtzb3J0ZWRCbG9nc31cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgfVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGUgcGF0aD0nY3JlYXRlJyBlbGVtZW50PXtcbiAgICAgICAgICA8QmxvZ0Zvcm0gY3JlYXRlQmxvZz17aGFuZGxlQ3JlYXRlfSAvPlxuICAgICAgICB9IC8+XG4gICAgICA8L1JvdXRlcz5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHBcbiJdLCJmaWxlIjoiL2hvbWUva2VuZWR5L2Rldi9ibG9nX2FwcGxpY2F0aW9uL2NsaWVudC9zcmMvQXBwLmpzeCJ9