import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13ad0a09"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=13ad0a09";
import blogService from "/src/services/blogs.js";
const Blog = ({ blogs, removeBlog, handleLike, loggedInUser }) => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const blog = blogs.find((b) => b.id === id);
  if (!blog) {
    return /* @__PURE__ */ jsxDEV("p", { style: { padding: 15 }, children: "Loading blog data..." }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
      lineNumber: 30,
      columnNumber: 12
    }, this);
  }
  const liking = async () => {
    if (!loggedInUser) return;
    await handleLike(blog);
  };
  const handleDelete = async () => {
    if (window.confirm(`Remove blog ${blog.title} by ${blog.author}`)) {
      try {
        await blogService.deleteBlog(blog.id);
        removeBlog(blog.id);
        navigate("/");
      } catch (error) {
        console.log(error);
      }
    }
  };
  const isOwner = loggedInUser && (blog.user?.username === loggedInUser.username || blog.user === loggedInUser.id || blog.user?.id === loggedInUser.id);
  return /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "20px" }, children: [
    /* @__PURE__ */ jsxDEV("h2", { style: { fontSize: "1.5em", margin: "10px 0" }, children: [
      blog.author,
      ": ",
      blog.title
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
      lineNumber: 58,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("a", { href: blog.url, target: "_blank", rel: "noreferrer", children: blog.url }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
      lineNumber: 63,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
      lineNumber: 62,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { margin: "5px 0" }, children: [
      "likes ",
      blog.likes,
      " ",
      loggedInUser && /* @__PURE__ */ jsxDEV("button", { onClick: liking, children: "like" }, void 0, false, {
        fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
        lineNumber: 69,
        columnNumber: 45
      }, this)
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
      lineNumber: 68,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { margin: "5px 0" }, children: [
      "Added by ",
      blog.user?.name || blog.user?.username || "unknown"
    ] }, void 0, true, {
      fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
      lineNumber: 72,
      columnNumber: 7
    }, this),
    isOwner && /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "10px" }, children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: handleDelete,
        style: {
          padding: "2px 6px",
          cursor: "pointer"
        },
        children: "remove"
      },
      void 0,
      false,
      {
        fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
        lineNumber: 78,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx",
    lineNumber: 57,
    columnNumber: 5
  }, this);
};
_s(Blog, "1JEIvPRIKJKnaO45RHf/GR9vcR4=", false, function() {
  return [useParams, useNavigate];
});
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/kenedy/dev/blog_application/client/src/pages/Blog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVc7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVlgsU0FBU0EsV0FBV0MsbUJBQW1CO0FBQ3ZDLE9BQU9DLGlCQUFpQjtBQUV4QixNQUFNQyxPQUFPQSxDQUFDLEVBQUVDLE9BQU9DLFlBQVlDLFlBQVlDLGFBQWEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hFLFFBQU0sRUFBRUMsR0FBRyxJQUFJVCxVQUFVO0FBQ3pCLFFBQU1VLFdBQVdULFlBQVk7QUFFN0IsUUFBTVUsT0FBT1AsTUFBTVEsS0FBSyxDQUFBQyxNQUFLQSxFQUFFSixPQUFPQSxFQUFFO0FBRXhDLE1BQUksQ0FBQ0UsTUFBTTtBQUNULFdBQU8sdUJBQUMsT0FBRSxPQUFPLEVBQUVHLFNBQVMsR0FBRyxHQUFHLG9DQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStDO0FBQUEsRUFDeEQ7QUFFQSxRQUFNQyxTQUFTLFlBQVk7QUFDekIsUUFBSSxDQUFDUixhQUFjO0FBQ25CLFVBQU1ELFdBQVdLLElBQUk7QUFBQSxFQUN2QjtBQUVBLFFBQU1LLGVBQWUsWUFBWTtBQUMvQixRQUFJQyxPQUFPQyxRQUFRLGVBQWVQLEtBQUtRLEtBQUssT0FBT1IsS0FBS1MsTUFBTSxFQUFFLEdBQUc7QUFDakUsVUFBSTtBQUNGLGNBQU1sQixZQUFZbUIsV0FBV1YsS0FBS0YsRUFBRTtBQUNwQ0osbUJBQVdNLEtBQUtGLEVBQUU7QUFDbEJDLGlCQUFTLEdBQUc7QUFBQSxNQUNkLFNBQVNZLE9BQU87QUFDZEMsZ0JBQVFDLElBQUlGLEtBQUs7QUFBQSxNQUNuQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTUcsVUFBVWxCLGlCQUNkSSxLQUFLZSxNQUFNQyxhQUFhcEIsYUFBYW9CLFlBQ3JDaEIsS0FBS2UsU0FBU25CLGFBQWFFLE1BQzNCRSxLQUFLZSxNQUFNakIsT0FBT0YsYUFBYUU7QUFHakMsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRW1CLFdBQVcsT0FBTyxHQUM5QjtBQUFBLDJCQUFDLFFBQUcsT0FBTyxFQUFFQyxVQUFVLFNBQVNDLFFBQVEsU0FBUyxHQUM5Q25CO0FBQUFBLFdBQUtTO0FBQUFBLE1BQU87QUFBQSxNQUFHVCxLQUFLUTtBQUFBQSxTQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQ0MsaUNBQUMsT0FBRSxNQUFNUixLQUFLb0IsS0FBSyxRQUFPLFVBQVMsS0FBSSxjQUNwQ3BCLGVBQUtvQixPQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVELFFBQVEsUUFBUSxHQUFFO0FBQUE7QUFBQSxNQUN2Qm5CLEtBQUtxQjtBQUFBQSxNQUFNO0FBQUEsTUFBRXpCLGdCQUFnQix1QkFBQyxZQUFPLFNBQVNRLFFBQVEsb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxTQURuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFZSxRQUFRLFFBQVEsR0FBRTtBQUFBO0FBQUEsTUFDcEJuQixLQUFLZSxNQUFNTyxRQUFRdEIsS0FBS2UsTUFBTUMsWUFBWTtBQUFBLFNBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUNGLFdBQ0MsdUJBQUMsU0FBSSxPQUFPLEVBQUVHLFdBQVcsT0FBTyxHQUM5QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBU1o7QUFBQUEsUUFDVCxPQUFPO0FBQUEsVUFDTEYsU0FBUztBQUFBLFVBQ1RvQixRQUFRO0FBQUEsUUFDVjtBQUFBLFFBQUU7QUFBQTtBQUFBLE1BTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxPQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0NBO0FBRUo7QUFBQzFCLEdBcEVLTCxNQUFJO0FBQUEsVUFDT0gsV0FDRUMsV0FBVztBQUFBO0FBQUEsS0FGeEJFO0FBc0VOLGVBQWVBO0FBQUksSUFBQWdDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsInVzZU5hdmlnYXRlIiwiYmxvZ1NlcnZpY2UiLCJCbG9nIiwiYmxvZ3MiLCJyZW1vdmVCbG9nIiwiaGFuZGxlTGlrZSIsImxvZ2dlZEluVXNlciIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsImJsb2ciLCJmaW5kIiwiYiIsInBhZGRpbmciLCJsaWtpbmciLCJoYW5kbGVEZWxldGUiLCJ3aW5kb3ciLCJjb25maXJtIiwidGl0bGUiLCJhdXRob3IiLCJkZWxldGVCbG9nIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIiwiaXNPd25lciIsInVzZXIiLCJ1c2VybmFtZSIsIm1hcmdpblRvcCIsImZvbnRTaXplIiwibWFyZ2luIiwidXJsIiwibGlrZXMiLCJuYW1lIiwiY3Vyc29yIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi4vc2VydmljZXMvYmxvZ3MnXG5cbmNvbnN0IEJsb2cgPSAoeyBibG9ncywgcmVtb3ZlQmxvZywgaGFuZGxlTGlrZSwgbG9nZ2VkSW5Vc2VyIH0pID0+IHtcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKClcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG5cbiAgY29uc3QgYmxvZyA9IGJsb2dzLmZpbmQoYiA9PiBiLmlkID09PSBpZClcblxuICBpZiAoIWJsb2cpIHtcbiAgICByZXR1cm4gPHAgc3R5bGU9e3sgcGFkZGluZzogMTUgfX0+TG9hZGluZyBibG9nIGRhdGEuLi48L3A+XG4gIH1cblxuICBjb25zdCBsaWtpbmcgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFsb2dnZWRJblVzZXIpIHJldHVyblxuICAgIGF3YWl0IGhhbmRsZUxpa2UoYmxvZylcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYFJlbW92ZSBibG9nICR7YmxvZy50aXRsZX0gYnkgJHtibG9nLmF1dGhvcn1gKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgYmxvZ1NlcnZpY2UuZGVsZXRlQmxvZyhibG9nLmlkKVxuICAgICAgICByZW1vdmVCbG9nKGJsb2cuaWQpXG4gICAgICAgIG5hdmlnYXRlKCcvJylcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGlzT3duZXIgPSBsb2dnZWRJblVzZXIgJiYgKFxuICAgIGJsb2cudXNlcj8udXNlcm5hbWUgPT09IGxvZ2dlZEluVXNlci51c2VybmFtZSB8fFxuICAgIGJsb2cudXNlciA9PT0gbG9nZ2VkSW5Vc2VyLmlkIHx8XG4gICAgYmxvZy51c2VyPy5pZCA9PT0gbG9nZ2VkSW5Vc2VyLmlkXG4gIClcblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAnMjBweCcgfX0+XG4gICAgICA8aDIgc3R5bGU9e3sgZm9udFNpemU6ICcxLjVlbScsIG1hcmdpbjogJzEwcHggMCcgfX0+XG4gICAgICAgIHtibG9nLmF1dGhvcn06IHtibG9nLnRpdGxlfVxuICAgICAgPC9oMj5cblxuICAgICAgPGRpdj5cbiAgICAgICAgPGEgaHJlZj17YmxvZy51cmx9IHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vcmVmZXJyZXJcIj5cbiAgICAgICAgICB7YmxvZy51cmx9XG4gICAgICAgIDwvYT5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbjogJzVweCAwJyB9fT5cbiAgICAgICAgbGlrZXMge2Jsb2cubGlrZXN9IHtsb2dnZWRJblVzZXIgJiYgPGJ1dHRvbiBvbkNsaWNrPXtsaWtpbmd9Pmxpa2U8L2J1dHRvbj59XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW46ICc1cHggMCcgfX0+XG4gICAgICAgIEFkZGVkIGJ5IHtibG9nLnVzZXI/Lm5hbWUgfHwgYmxvZy51c2VyPy51c2VybmFtZSB8fCAndW5rbm93bid9XG4gICAgICA8L2Rpdj5cblxuICAgICAge2lzT3duZXIgJiYgKFxuICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogJzEwcHgnIH19PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURlbGV0ZX1cbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIHBhZGRpbmc6ICcycHggNnB4JyxcbiAgICAgICAgICAgICAgY3Vyc29yOiAncG9pbnRlcidcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgcmVtb3ZlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nXG4iXSwiZmlsZSI6Ii9ob21lL2tlbmVkeS9kZXYvYmxvZ19hcHBsaWNhdGlvbi9jbGllbnQvc3JjL3BhZ2VzL0Jsb2cuanN4In0=