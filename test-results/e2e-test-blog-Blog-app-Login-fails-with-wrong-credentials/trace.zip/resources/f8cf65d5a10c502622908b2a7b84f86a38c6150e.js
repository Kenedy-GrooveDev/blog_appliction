import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13ad0a09"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/kenedy/dev/blog_application/client/src/components/Notification.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=13ad0a09"; const useState = __vite__cjsImport3_react["useState"];
const Notification = ({ message, variant }) => {
  _s();
  const [remove, setRemove] = useState(false);
  if (!message || remove) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      style: {
        borderWidth: "2px",
        borderStyle: "solid",
        borderColor: variant === "red" ? "red" : "green",
        backgroundColor: "lightgray",
        borderRadius: "15px",
        padding: "15px",
        color: variant === "red" ? "red" : "green",
        marginBottom: "10px"
      },
      className: "notify",
      children: [
        message,
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setRemove(true), children: "X" }, void 0, false, {
          fileName: "/home/kenedy/dev/blog_application/client/src/components/Notification.jsx",
          lineNumber: 45,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/home/kenedy/dev/blog_application/client/src/components/Notification.jsx",
      lineNumber: 31,
      columnNumber: 5
    },
    this
  );
};
_s(Notification, "qxZ7hIiR/XywTeim4/5PeYNGxYA=");
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/kenedy/dev/blog_application/client/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/kenedy/dev/blog_application/client/src/components/Notification.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCTixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsZUFBZUEsQ0FBQyxFQUFFQyxTQUFTQyxRQUFRLE1BQU07QUFBQUMsS0FBQTtBQUM3QyxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSU4sU0FBUyxLQUFLO0FBRzFDLE1BQUksQ0FBQ0UsV0FBV0csUUFBUTtBQUN0QixXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE9BQU87QUFBQSxRQUNMRSxhQUFhO0FBQUEsUUFDYkMsYUFBYTtBQUFBLFFBQ2JDLGFBQWFOLFlBQVksUUFBUSxRQUFRO0FBQUEsUUFDekNPLGlCQUFpQjtBQUFBLFFBQ2pCQyxjQUFjO0FBQUEsUUFDZEMsU0FBUztBQUFBLFFBQ1RDLE9BQU9WLFlBQVksUUFBUSxRQUFRO0FBQUEsUUFDbkNXLGNBQWM7QUFBQSxNQUNoQjtBQUFBLE1BQ0EsV0FBVTtBQUFBLE1BRVRaO0FBQUFBO0FBQUFBLFFBQ0QsdUJBQUMsWUFBTyxTQUFTLE1BQU1JLFVBQVUsSUFBSSxHQUFHLGlCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUE7QUFBQTtBQUFBLElBZDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWVBO0FBRUo7QUFBQ0YsR0ExQktILGNBQVk7QUFBQSxLQUFaQTtBQTRCTixlQUFlQTtBQUFZLElBQUFjO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTm90aWZpY2F0aW9uIiwibWVzc2FnZSIsInZhcmlhbnQiLCJfcyIsInJlbW92ZSIsInNldFJlbW92ZSIsImJvcmRlcldpZHRoIiwiYm9yZGVyU3R5bGUiLCJib3JkZXJDb2xvciIsImJhY2tncm91bmRDb2xvciIsImJvcmRlclJhZGl1cyIsInBhZGRpbmciLCJjb2xvciIsIm1hcmdpbkJvdHRvbSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgTm90aWZpY2F0aW9uID0gKHsgbWVzc2FnZSwgdmFyaWFudCB9KSA9PiB7XG4gIGNvbnN0IFtyZW1vdmUsIHNldFJlbW92ZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuXG4gIGlmICghbWVzc2FnZSB8fCByZW1vdmUpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBzdHlsZT17e1xuICAgICAgICBib3JkZXJXaWR0aDogJzJweCcsXG4gICAgICAgIGJvcmRlclN0eWxlOiAnc29saWQnLFxuICAgICAgICBib3JkZXJDb2xvcjogdmFyaWFudCA9PT0gJ3JlZCcgPyAncmVkJyA6ICdncmVlbicsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ2xpZ2h0Z3JheScsXG4gICAgICAgIGJvcmRlclJhZGl1czogJzE1cHgnLFxuICAgICAgICBwYWRkaW5nOiAnMTVweCcsXG4gICAgICAgIGNvbG9yOiB2YXJpYW50ID09PSAncmVkJyA/ICdyZWQnIDogJ2dyZWVuJyxcbiAgICAgICAgbWFyZ2luQm90dG9tOiAnMTBweCcsXG4gICAgICB9fVxuICAgICAgY2xhc3NOYW1lPSdub3RpZnknXG4gICAgPlxuICAgICAge21lc3NhZ2V9XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFJlbW92ZSh0cnVlKX0+WDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvblxuIl0sImZpbGUiOiIvaG9tZS9rZW5lZHkvZGV2L2Jsb2dfYXBwbGljYXRpb24vY2xpZW50L3NyYy9jb21wb25lbnRzL05vdGlmaWNhdGlvbi5qc3gifQ==