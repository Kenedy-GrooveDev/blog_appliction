import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Login.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13ad0a09"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/kenedy/dev/blog_application/client/src/pages/Login.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import LoginForm from "/src/components/LoginForm.jsx";
import Notification from "/src/components/Notification.jsx";
const Login = ({ notifyMessage, setPassword, setUsername, handleLogin, username, password }) => /* @__PURE__ */ jsxDEV("div", { children: [
  /* @__PURE__ */ jsxDEV("h1", { children: "log in to application" }, void 0, false, {
    fileName: "/home/kenedy/dev/blog_application/client/src/pages/Login.jsx",
    lineNumber: 25,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV(
    Notification,
    {
      message: notifyMessage?.message,
      variant: notifyMessage?.variant
    },
    void 0,
    false,
    {
      fileName: "/home/kenedy/dev/blog_application/client/src/pages/Login.jsx",
      lineNumber: 27,
      columnNumber: 5
    },
    this
  ),
  /* @__PURE__ */ jsxDEV(
    LoginForm,
    {
      handleLogin,
      username,
      password,
      handleUsernameChange: ({ target }) => setUsername(target.value),
      handlePasswordChange: ({ target }) => setPassword(target.value)
    },
    void 0,
    false,
    {
      fileName: "/home/kenedy/dev/blog_application/client/src/pages/Login.jsx",
      lineNumber: 32,
      columnNumber: 5
    },
    this
  )
] }, void 0, true, {
  fileName: "/home/kenedy/dev/blog_application/client/src/pages/Login.jsx",
  lineNumber: 24,
  columnNumber: 1
}, this);
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/kenedy/dev/blog_application/client/src/pages/Login.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/kenedy/dev/blog_application/client/src/pages/Login.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFMSixPQUFPQSxlQUFlO0FBQ3RCLE9BQU9DLGtCQUFrQjtBQUV6QixNQUFNQyxRQUFRQSxDQUFDLEVBQUVDLGVBQWVDLGFBQWFDLGFBQWFDLGFBQWFDLFVBQVVDLFNBQVMsTUFDeEYsdUJBQUMsU0FDQztBQUFBLHlCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5QjtBQUFBLEVBRXpCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxTQUFTTCxlQUFlTTtBQUFBQSxNQUN4QixTQUFTTixlQUFlTztBQUFBQTtBQUFBQSxJQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFFa0M7QUFBQSxFQUdsQztBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0Esc0JBQXNCLENBQUMsRUFBRUMsT0FBTyxNQUFNTixZQUFZTSxPQUFPQyxLQUFLO0FBQUEsTUFDOUQsc0JBQXNCLENBQUMsRUFBRUQsT0FBTyxNQUFNUCxZQUFZTyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxJQUxoRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLa0U7QUFBQSxLQWJwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BZUE7QUFDREMsS0FqQktYO0FBbUJOLGVBQWVBO0FBQUssSUFBQVc7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTG9naW5Gb3JtIiwiTm90aWZpY2F0aW9uIiwiTG9naW4iLCJub3RpZnlNZXNzYWdlIiwic2V0UGFzc3dvcmQiLCJzZXRVc2VybmFtZSIsImhhbmRsZUxvZ2luIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsIm1lc3NhZ2UiLCJ2YXJpYW50IiwidGFyZ2V0IiwidmFsdWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMb2dpbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExvZ2luRm9ybSBmcm9tICcuLi9jb21wb25lbnRzL0xvZ2luRm9ybSdcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi4vY29tcG9uZW50cy9Ob3RpZmljYXRpb24nXG5cbmNvbnN0IExvZ2luID0gKHsgbm90aWZ5TWVzc2FnZSwgc2V0UGFzc3dvcmQsIHNldFVzZXJuYW1lLCBoYW5kbGVMb2dpbiwgdXNlcm5hbWUsIHBhc3N3b3JkIH0pID0+IChcbiAgPGRpdj5cbiAgICA8aDE+bG9nIGluIHRvIGFwcGxpY2F0aW9uPC9oMT5cblxuICAgIDxOb3RpZmljYXRpb25cbiAgICAgIG1lc3NhZ2U9e25vdGlmeU1lc3NhZ2U/Lm1lc3NhZ2V9XG4gICAgICB2YXJpYW50PXtub3RpZnlNZXNzYWdlPy52YXJpYW50fVxuICAgIC8+XG5cbiAgICA8TG9naW5Gb3JtXG4gICAgICBoYW5kbGVMb2dpbj17aGFuZGxlTG9naW59XG4gICAgICB1c2VybmFtZT17dXNlcm5hbWV9XG4gICAgICBwYXNzd29yZD17cGFzc3dvcmR9XG4gICAgICBoYW5kbGVVc2VybmFtZUNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICBoYW5kbGVQYXNzd29yZENoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgLz5cbiAgPC9kaXY+XG4pXG5cbmV4cG9ydCBkZWZhdWx0IExvZ2luXG4iXSwiZmlsZSI6Ii9ob21lL2tlbmVkeS9kZXYvYmxvZ19hcHBsaWNhdGlvbi9jbGllbnQvc3JjL3BhZ2VzL0xvZ2luLmpzeCJ9